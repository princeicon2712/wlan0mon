### Installation Termux
Quick installation for Termux
```bash
wget https://raw.githubusercontent.com/R1punk/wlan0mon/main/install && bash install
``` 
### Usage:

- ```Root Only```
- ```start``` - Monitor mode
- ```stop``` - Stop Monitor Mode


### Nethunter
```bash
git clone https://github.com/R1punk/wlan0mon && cd wlan0mon
```
- ```chmod +x *```

## Usage:
- ```./monen``` - Monitor mode
- ```./mondis``` - Stop Monitor Mode
